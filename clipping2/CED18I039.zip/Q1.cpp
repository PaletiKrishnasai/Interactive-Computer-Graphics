//CED18I039
#include <GL/freeglut.h> 
#include <bits/stdc++.h> 


using namespace std;
#define LENGTH 600
#define HEIGHT 600


void changeViewPort(int w, int h)
{
	glViewport(0, 0, w, h);
}

void window_color()
{

	glClearColor(1.0,1.0,1.0,0.0);
	glClear(GL_COLOR_BUFFER_BIT);

}

int Point_Sign(int x1, int y1, int x2, int y2, int x, int y)
{
    int c = (((x2-x1)*(y-y1) - (y2-y1)*(x-x1))>=0)? 1:-1;
    return c;
}

int Point_Check(vector<pair<int,int>> P, vector<pair<int,int>>W, int n)
{
    int p=0;
    int s = Point_Sign(W[p].first,W[p].second,W[p+1].first, W[p+1].second,P[0].first, P[0].second);
    cout << s;
    while(p<n-1)
    {
        cout << Point_Sign(W[p].first,W[p].second,W[p+1].first, W[p+1].second,P[0].first, P[0].second);
        if(s!=Point_Sign(W[p].first,W[p].second,W[p+1].first, W[p+1].second,P[0].first, P[0].second))
        {
            cout << "Point is not inside the polygon!" << endl;
            glPointSize(2.5);
            glColor3f(1,0,0);
            glBegin(GL_POINTS);
                glVertex2f(P[0].first, P[0].second);
            glEnd();
            return 0;
        }
        p++;
    }
    cout << Point_Sign(W[p].first,W[p].second,W[0].first, W[0].second,P[0].first, P[0].second) << endl;
    if(s!=Point_Sign(W[p].first,W[p].second,W[0].first, W[0].second,P[0].first, P[0].second))
    {
     cout << "Point is not inside the polygon!" << endl;
     glPointSize(2.5);
     glColor3f(1,0,0);
     glBegin(GL_POINTS);
        glVertex2f(P[0].first, P[0].second);
     glEnd();
    }
    else
    {
     cout << "Point is inside the polygon" << endl;
     glPointSize(2.5);
     glColor3f(0,1,0);
     glBegin(GL_POINTS);
        glVertex2f(P[0].first, P[0].second);
     glEnd();
    }
    return 0;
}

void Point_Clipping()
{
    int p1,p2;
    int w1,w2;
    int k,n;
    vector<pair<int,int>>P;
    vector<pair<int,int>>W;
    cout << "Number of sides: ";
    cin >> n;
    k=n;
    cout << "Enter the vertices of the polygon : " << endl;
    while(n-->0)
    {
        cin >> w1 >> w2;
        W.push_back(make_pair(w1,w2));
    }
    n=k;
    cout << "Enter the coordinates of the point: ";
    cin >> p1 >> p2;
    P.push_back(make_pair(p1,p2));
    glPointSize(1);
    glColor3f(0,0,0);
    glBegin(GL_LINE_LOOP);
    while(n-->0)
        glVertex2f(W[n].first, W[n].second);   
    glEnd();
    Point_Check(P,W,k);
    
    
}


void draw()
{
    
	window_color();
    srand(time(0));
    Point_Clipping();

	glFlush();
}

int main(int argc,char** argv)
{
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(LENGTH, HEIGHT);
	glutCreateWindow("ICG"); 
	glutReshapeFunc(changeViewPort);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0.0, LENGTH, 0.0, HEIGHT);
	glutDisplayFunc(draw);
	glutMainLoop();
}





